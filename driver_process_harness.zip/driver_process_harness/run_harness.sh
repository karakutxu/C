#!/bin/sh
set -eu

DRIVER="${1:-./protocol_driver}"
HARNESS="${HARNESS:-./driver_process_harness}"

if [ ! -x "$DRIVER" ]; then
    echo "Driver executable not found or not executable: $DRIVER" >&2
    exit 2
fi

if [ ! -x "$HARNESS" ]; then
    echo "Harness executable not found: $HARNESS" >&2
    echo "Build it using the project's shared include paths first." >&2
    exit 2
fi

exec "$HARNESS" "$DRIVER"
