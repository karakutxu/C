# Real-driver process integration harness

This harness runs the **real driver executable** as a child process. It creates
four AF_UNIX mock servers for PME, SlotMgr, CSH event handler and CSH RX, then
accepts the real driver's outbound connections.

It is plain C; it does not use Unity or Ceedling and does not link against the
driver implementation.

## Files

- `driver_process_harness.c` — test executable source.
- `run_harness.sh` — example build/run wrapper; adapt include paths and library
  dependencies to the repository.

## Important assumptions to confirm in the project

1. Shared message headers are named `hcs_messages.h` and `unix_sock.h`.
2. The shared headers define `PME_SOCK`, `SLOTMGR_SOCK`, `CSH_EVT_0_SOCK`,
   `CSH_PROC_RX_0_SOCK`, `MsgInitProdrv_t`, `MsgInitialised_t`,
   `MsgPrepareFrame_t`, `MsgTxStart_t`, `MsgResetProdrv_t`, `MsgID_t`,
   `MSG_PROTO_RESET`, `MSG_INITIALISED`, `MSG_TX_START`, and `CHUNK1_SIZE`.
3. The driver's current `main()` starts HCS index 0. The supplied `main()` was
   described as hardcoding `proto_main_loop(0)` and ignoring arguments. Passing
   `"0"` to it does not change that behaviour.
4. The driver must be corrected so that its TAP/TUN read does not block the
   socket event loop. Otherwise the test may hang after startup or after the
   first socket event.
5. The driver uses fixed `/tmp` socket paths. Run only when no other process is
   using these paths. This harness refuses to unlink paths that already exist.

## Build

Use the same include directories and compile definitions as the driver build.
For example (replace the paths and library list with the real project values):

```sh
cc -std=c11 -Wall -Wextra -Wpedantic \
  -I/path/to/shared/include \
  -I/path/to/driver/include \
  driver_process_harness.c \
  -o driver_process_harness
```

If your shared headers require other project headers or defines, add them to
this command. The harness should not link `unix_sock.c` just to get socket
helpers; it uses its own safe listener/send/receive functions.

## Run

```sh
./driver_process_harness ./path/to/real-driver-executable
```

The driver executable must be built with its normal production handlers and
event loop. Do not substitute the colleague's mock driver.

## Tests currently enabled

- Driver startup and connections to the four mock subsystem endpoints.
- `MSG_INIT_PRODRV` sent from mock PME; expects `MSG_INITIALISED` on mock
  SlotMgr and checks the HCS index.
- `MSG_PROTO_RESET` sent from mock PME; checks only that the process stays
  alive, because the current protocol defines no reset response.

## Frame-preparation test

The source includes `test_prepare_frame()`. Enable it by compiling with
`-DENABLE_PREPARE_FRAME_TEST`, but only after the test fixture sends any
configuration messages needed to make the driver's frame state valid. It
expects `MSG_TX_START` on the CSH event socket and checks the transaction ID.
A zeroed `ScheduleMeta_t` is deterministic, but may not be a semantically valid
schedule for your application.

## CSH RX test is deliberately not guessed

In the supplied snippets, the dispatcher reads a `MsgID_t` from the incoming
buffer, but the shown `RX_LAYER_2_CHUNK` structure begins with `FLAGS` and has
no message ID. Confirm the exact on-wire layout (including whether the ID is a
separate prefix) and the correct byte length before adding an RX test. The
current `read_socket()` also performs one `recv()` on a stream socket, so it
must be corrected to handle partial reads / message framing consistently.

## Reset test limitation

A successful `send()` only proves that bytes were accepted by the local socket.
The process-alive check verifies that the driver did not immediately exit, not
that every reset field was reset correctly. To verify reset semantics, expose
an existing observable effect or add a test-only diagnostic/state snapshot;
avoid adding a production ACK unless it is part of the intended protocol.
