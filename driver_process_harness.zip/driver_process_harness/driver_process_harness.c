/*
 * Process-level integration harness for the real protocol driver.
 *
 * Build this against the same shared message/socket headers as the driver.
 * This test executable is NOT linked to the driver's implementation.
 *
 * IMPORTANT:
 * - Run only in an isolated test environment: the project uses fixed /tmp
 *   AF_UNIX socket paths.
 * - This harness refuses to unlink existing socket paths. Stop other test/
 *   production processes first and remove stale socket files deliberately.
 * - The exact shared headers must provide the message types/constants below.
 */

#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

/*
 * Change these include names only if your repository uses different names.
 * They are based on the headers in the source you supplied.
 */
#include "hcs_messages.h"
#include "unix_sock.h"

/* Real driver executable path; override at runtime with argv[1]. */
#define DEFAULT_DRIVER_EXECUTABLE "./protocol_driver"
#define TEST_TIMEOUT_MS 5000
#define TEST_HCS_INDEX 0

typedef struct test_env {
    int pme_listener;
    int slotmgr_listener;
    int csh_evt_listener;
    int csh_rx_listener;

    int pme_fd;
    int slotmgr_fd;
    int csh_evt_fd;
    int csh_rx_fd;

    pid_t driver_pid;

    const char *pme_path;
    const char *slotmgr_path;
    const char *csh_evt_path;
    const char *csh_rx_path;
} test_env_t;

static test_env_t g = {
    .pme_listener = -1, .slotmgr_listener = -1,
    .csh_evt_listener = -1, .csh_rx_listener = -1,
    .pme_fd = -1, .slotmgr_fd = -1,
    .csh_evt_fd = -1, .csh_rx_fd = -1,
    .driver_pid = -1
};

static int g_failures = 0;

static void log_line(const char *level, const char *msg)
{
    fprintf(level[0] == 'F' ? stderr : stdout, "[%s] %s\n", level, msg);
}

static void fail(const char *msg)
{
    fprintf(stderr, "[FAIL] %s\n", msg);
    ++g_failures;
}

static void pass(const char *msg)
{
    printf("[PASS] %s\n", msg);
}

static int path_exists(const char *path)
{
    struct stat st;
    return lstat(path, &st) == 0;
}

static int create_unix_listener(const char *path)
{
    int fd = -1;
    struct sockaddr_un addr;

    if (strlen(path) >= sizeof(addr.sun_path)) {
        fprintf(stderr, "[FAIL] AF_UNIX path too long: %s\n", path);
        return -1;
    }

    /*
     * Do not blindly unlink: if another process owns a live socket path,
     * unlinking it can break that process's clients.
     */
    if (path_exists(path)) {
        fprintf(stderr,
                "[FAIL] Socket path already exists: %s\n"
                "Stop the other process and remove the stale socket only "
                "after confirming it is not in use.\n", path);
        return -1;
    }

    fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) {
        perror("socket");
        return -1;
    }

    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    memcpy(addr.sun_path, path, strlen(path) + 1);

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(fd);
        return -1;
    }

    if (listen(fd, 4) < 0) {
        perror("listen");
        close(fd);
        unlink(path);
        return -1;
    }

    return fd;
}

static int wait_fd(int fd, short events, int timeout_ms)
{
    struct pollfd pfd;
    int rc;

    pfd.fd = fd;
    pfd.events = events;
    pfd.revents = 0;

    do {
        rc = poll(&pfd, 1, timeout_ms);
    } while (rc < 0 && errno == EINTR);

    if (rc <= 0)
        return rc;

    if (pfd.revents & (POLLERR | POLLHUP | POLLNVAL))
        return -1;

    return (pfd.revents & events) ? 1 : -1;
}

/* Send all bytes: SOCK_STREAM does not preserve message boundaries. */
static int send_all(int fd, const void *data, size_t len)
{
    const uint8_t *p = (const uint8_t *)data;
    size_t sent = 0;

    while (sent < len) {
        ssize_t n = send(fd, p + sent, len - sent, MSG_NOSIGNAL);
        if (n < 0 && errno == EINTR)
            continue;
        if (n <= 0)
            return -1;
        sent += (size_t)n;
    }
    return 0;
}

/* Receive exactly len bytes, with a total deadline. */
static int recv_all_timeout(int fd, void *data, size_t len, int timeout_ms)
{
    uint8_t *p = (uint8_t *)data;
    size_t received = 0;
    struct timespec start, now;

    clock_gettime(CLOCK_MONOTONIC, &start);

    while (received < len) {
        long elapsed_ms;
        int remaining;

        clock_gettime(CLOCK_MONOTONIC, &now);
        elapsed_ms = (now.tv_sec - start.tv_sec) * 1000L
                   + (now.tv_nsec - start.tv_nsec) / 1000000L;
        remaining = timeout_ms - (int)elapsed_ms;
        if (remaining <= 0)
            return -2; /* timeout */

        int ready = wait_fd(fd, POLLIN, remaining);
        if (ready == 0)
            return -2;
        if (ready < 0)
            return -1;

        ssize_t n = recv(fd, p + received, len - received, 0);
        if (n < 0 && errno == EINTR)
            continue;
        if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK))
            continue;
        if (n <= 0)
            return -1;
        received += (size_t)n;
    }
    return 0;
}

static int accept_timeout(int listener, const char *name, int timeout_ms)
{
    int ready = wait_fd(listener, POLLIN, timeout_ms);
    if (ready <= 0) {
        fprintf(stderr, "[FAIL] Timed out waiting for driver connection: %s\n",
                name);
        return -1;
    }

    int fd;
    do {
        fd = accept(listener, NULL, NULL);
    } while (fd < 0 && errno == EINTR);

    if (fd < 0) {
        perror("accept");
        return -1;
    }

    printf("[MOCK] Driver connected to %s\n", name);
    return fd;
}

static void create_mock_servers(void)
{
    g.pme_path = PME_SOCK;
    g.slotmgr_path = SLOTMGR_SOCK;
    g.csh_evt_path = CSH_EVT_0_SOCK;
    g.csh_rx_path = CSH_PROC_RX_0_SOCK;

    printf("[TEST] Creating mock subsystem sockets:\n"
           "       PME      %s\n"
           "       SlotMgr  %s\n"
           "       CSH event %s\n"
           "       CSH RX    %s\n",
           g.pme_path, g.slotmgr_path, g.csh_evt_path, g.csh_rx_path);

    g.pme_listener = create_unix_listener(g.pme_path);
    g.slotmgr_listener = create_unix_listener(g.slotmgr_path);
    g.csh_evt_listener = create_unix_listener(g.csh_evt_path);
    g.csh_rx_listener = create_unix_listener(g.csh_rx_path);

    if (g.pme_listener < 0 || g.slotmgr_listener < 0 ||
        g.csh_evt_listener < 0 || g.csh_rx_listener < 0) {
        fail("Could not create all mock subsystem listeners");
        exit(EXIT_FAILURE);
    }
}

static void start_real_driver(const char *executable)
{
    g.driver_pid = fork();
    if (g.driver_pid < 0) {
        perror("fork");
        fail("Could not fork driver");
        exit(EXIT_FAILURE);
    }

    if (g.driver_pid == 0) {
        /*
         * The supplied main() currently ignores argv and calls
         * proto_main_loop(0). Passing the index is harmless, but it only
         * takes effect after main() is updated to parse argv.
         */
        execl(executable, executable, "0", (char *)NULL);
        perror("execl");
        _exit(127);
    }

    printf("[TEST] Started real driver process PID=%ld (%s)\n",
           (long)g.driver_pid, executable);
}

static void connect_all_mocks(void)
{
    g.pme_fd = accept_timeout(g.pme_listener, "PME", TEST_TIMEOUT_MS);
    g.slotmgr_fd = accept_timeout(g.slotmgr_listener, "SlotMgr", TEST_TIMEOUT_MS);
    g.csh_evt_fd = accept_timeout(g.csh_evt_listener, "CSH event handler",
                                  TEST_TIMEOUT_MS);
    g.csh_rx_fd = accept_timeout(g.csh_rx_listener, "CSH RX", TEST_TIMEOUT_MS);

    if (g.pme_fd < 0 || g.slotmgr_fd < 0 ||
        g.csh_evt_fd < 0 || g.csh_rx_fd < 0) {
        fail("Driver failed to connect to all mock endpoints");
        exit(EXIT_FAILURE);
    }
    pass("Real driver connected to all four mock subsystem endpoints");
}

static void test_init_prodrv(void)
{
    MsgInitProdrv_t request;
    MsgInitialised_t response;

    memset(&request, 0, sizeof(request));
    request.id = MSG_INIT_PRODRV;
    request.chunk1_bytes = CHUNK1_SIZE;
    request.chunkn_bytes = 0;
    request.prepare_l2_frame_to_tx_ms = 0;

    printf("\n[TEST] MSG_INIT_PRODRV -> MSG_INITIALISED\n");

    if (send_all(g.pme_fd, &request, sizeof(request)) < 0) {
        fail("Could not send MSG_INIT_PRODRV from mock PME");
        return;
    }

    int rc = recv_all_timeout(g.slotmgr_fd, &response, sizeof(response),
                              TEST_TIMEOUT_MS);
    if (rc == -2) {
        fail("Timed out waiting for initialisation response on SlotMgr");
        return;
    }
    if (rc < 0) {
        fail("Failed reading initialisation response from SlotMgr");
        return;
    }

    if (response.id != MSG_INITIALISED) {
        fprintf(stderr, "[FAIL] Expected MSG_INITIALISED, got id=%d\n",
                (int)response.id);
        ++g_failures;
        return;
    }
    if (response.hcs_index != TEST_HCS_INDEX) {
        fprintf(stderr, "[FAIL] Expected hcs_index=%d, got %d\n",
                TEST_HCS_INDEX, response.hcs_index);
        ++g_failures;
        return;
    }

    pass("MSG_INITIALISED received on mock SlotMgr with the expected HCS index");
}

/*
 * This test intentionally verifies only the externally observable protocol:
 * a valid MSG_PREPARE_FRAME should result in MSG_TX_START on CSH event.
 *
 * The driver's frame configuration must already be valid. If the real
 * implementation requires additional PME/SlotMgr configuration messages
 * before frame preparation, send those setup messages here first.
 */
static void test_prepare_frame(void)
{
    MsgPrepareFrame_t request;
    MsgTxStart_t response;

    memset(&request, 0, sizeof(request));
    request.id = MSG_PREPARE_FRAME;
    request.tr_id = 0x1234;

    /* ScheduleMeta_t is zero-initialised for a deterministic test message. */

    printf("\n[TEST] MSG_PREPARE_FRAME -> MSG_TX_START\n");

    if (send_all(g.slotmgr_fd, &request, sizeof(request)) < 0) {
        fail("Could not send MSG_PREPARE_FRAME from mock SlotMgr");
        return;
    }

    int rc = recv_all_timeout(g.csh_evt_fd, &response, sizeof(response),
                              TEST_TIMEOUT_MS);
    if (rc == -2) {
        fail("Timed out waiting for MSG_TX_START on CSH event socket. "
             "Check whether the driver requires further frame configuration.");
        return;
    }
    if (rc < 0) {
        fail("Failed reading MSG_TX_START from CSH event socket");
        return;
    }

    if (response.id != MSG_TX_START) {
        fprintf(stderr, "[FAIL] Expected MSG_TX_START, got id=%d\n",
                (int)response.id);
        ++g_failures;
        return;
    }
    if (response.tr_id != request.tr_id) {
        fprintf(stderr, "[FAIL] TX_START transaction ID mismatch: expected "
                "0x%04x, got 0x%04x\n", request.tr_id, response.tr_id);
        ++g_failures;
        return;
    }

    pass("MSG_TX_START received on CSH event with matching transaction ID");
}

/*
 * Reset has no response defined in the supplied implementation. This test
 * sends it and checks that the process remains alive; it does NOT prove that
 * all reset state was correctly cleared.
 */
static void test_proto_reset(void)
{
    MsgResetProdrv_t request;
    int status = 0;

    memset(&request, 0, sizeof(request));
    request.id = MSG_PROTO_RESET;

    printf("\n[TEST] MSG_PROTO_RESET (no protocol ACK defined)\n");

    if (send_all(g.pme_fd, &request, sizeof(request)) < 0) {
        fail("Could not send MSG_PROTO_RESET from mock PME");
        return;
    }

    usleep(100000);

    if (g.driver_pid <= 0) {
        fail("Driver PID is invalid after reset request");
        return;
    }

    pid_t rc = waitpid(g.driver_pid, &status, WNOHANG);
    if (rc == g.driver_pid) {
        g.driver_pid = -1;
        fail("Driver exited after MSG_PROTO_RESET");
        return;
    }
    if (rc < 0 && errno != EINTR) {
        perror("waitpid");
        fail("Could not check driver process after reset");
        return;
    }

    pass("Driver process remained alive after MSG_PROTO_RESET");
}

/*
 * CSH RX note:
 * Your supplied source has a protocol-definition inconsistency: the dispatcher
 * identifies messages by MsgID_t, but the RX_LAYER_2_CHUNK definition shown
 * starts with FLAGS and has no id field. The actual wire layout / framing must
 * be confirmed before a safe, meaningful RX test can be added here. Sending a
 * guessed struct would risk testing malformed input rather than valid RX.
 */

static void close_fd(int *fd)
{
    if (*fd >= 0) {
        close(*fd);
        *fd = -1;
    }
}

static void stop_driver(void)
{
    if (g.driver_pid > 0) {
        int status;
        pid_t rc = waitpid(g.driver_pid, &status, WNOHANG);
        if (rc == 0) {
            kill(g.driver_pid, SIGTERM);
            for (int i = 0; i < 20; ++i) {
                rc = waitpid(g.driver_pid, &status, WNOHANG);
                if (rc == g.driver_pid)
                    break;
                usleep(50000);
            }
            if (rc == 0) {
                kill(g.driver_pid, SIGKILL);
                (void)waitpid(g.driver_pid, &status, 0);
            }
        }
        g.driver_pid = -1;
    }
}

static void cleanup(void)
{
    stop_driver();

    close_fd(&g.pme_fd);
    close_fd(&g.slotmgr_fd);
    close_fd(&g.csh_evt_fd);
    close_fd(&g.csh_rx_fd);

    close_fd(&g.pme_listener);
    close_fd(&g.slotmgr_listener);
    close_fd(&g.csh_evt_listener);
    close_fd(&g.csh_rx_listener);

    /*
     * These paths were created by this harness. Remove only these exact paths.
     * The driver's own listener path (PRODRV_0_SOCK) is not ours to unlink.
     */
    if (g.pme_path) unlink(g.pme_path);
    if (g.slotmgr_path) unlink(g.slotmgr_path);
    if (g.csh_evt_path) unlink(g.csh_evt_path);
    if (g.csh_rx_path) unlink(g.csh_rx_path);
}

int main(int argc, char **argv)
{
    const char *driver_executable =
        (argc > 1 && argv[1] && argv[1][0]) ?
        argv[1] : DEFAULT_DRIVER_EXECUTABLE;

    signal(SIGPIPE, SIG_IGN);

    printf("=== Real-driver process integration tests ===\n");
    printf("Driver executable: %s\n", driver_executable);

    create_mock_servers();
    start_real_driver(driver_executable);
    connect_all_mocks();

    test_init_prodrv();

    /*
     * Frame preparation depends on the driver's real frame configuration.
     * Leave this enabled once the test fixture performs all required setup.
     */
#ifdef ENABLE_PREPARE_FRAME_TEST
    test_prepare_frame();
#endif

    test_proto_reset();

    cleanup();

    if (g_failures) {
        fprintf(stderr, "\nRESULT: FAIL (%d failure(s))\n", g_failures);
        return EXIT_FAILURE;
    }

    printf("\nRESULT: PASS\n");
    return EXIT_SUCCESS;
}
